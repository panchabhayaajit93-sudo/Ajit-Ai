AJIT AI - Android starter project

Kya included hai:
- Simple Google Assistant-inspired clean UI
- Hinglish/Hindi speech input (tap mic)
- Text-to-speech reply
- Optional Make.com webhook POST integration

IMPORTANT LIMITATION:
Ye starter version background mein continuously "Hey Ajit" nahi sunta. Android par always-on wake word ke liye alag wake-word engine, foreground service, microphone permissions, battery settings, aur device-specific testing chahiye. Is ZIP ko always-on ready app na samjhein.

APK banane ke liye:
1. Android Studio install karein (computer/laptop required).
2. Android Studio > Open > is ZIP ko extract karke AjitAI_Android_Project folder select karein.
3. Gradle sync complete hone dein.
4. Phone par USB debugging enable karein, ya Build > Build Bundle(s) / APK(s) > Build APK(s) use karein.
5. APK output app/build/outputs/apk/debug/app-debug.apk mein milega.

Make.com:
1. App kholkar Make.com webhook URL field mein apna webhook URL paste karein.
2. Mic dabakar boliye.
3. App JSON POST karega: {"text":"...","assistant":"Ajit AI","language":"Hinglish"}

Security:
Webhook URL private rakhein. Is starter app mein API key hardcode nahi ki gayi hai.
