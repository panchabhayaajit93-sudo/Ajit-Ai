package com.ajit.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status, conversation;
    private EditText webhook;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private static final int REQ_AUDIO = 41;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        setupRecognizer();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 34, 28, 24);
        page.setBackgroundColor(0xFFFFFFFF);

        TextView title = new TextView(this);
        title.setText("Ajit AI");
        title.setTextColor(0xFF202124);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        page.addView(title, new LinearLayout.LayoutParams(-1, 70));

        TextView subtitle = new TextView(this);
        subtitle.setText("Your Hinglish voice assistant");
        subtitle.setTextColor(0xFF5F6368);
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle);

        TextView orb = new TextView(this);
        orb.setText("🎙️");
        orb.setTextSize(54);
        orb.setGravity(Gravity.CENTER);
        orb.setTextColor(0xFF4285F4);
        LinearLayout.LayoutParams orbParams = new LinearLayout.LayoutParams(-1, 180);
        orbParams.topMargin = 20;
        page.addView(orb, orbParams);

        status = new TextView(this);
        status.setText("Ready • Mic button dabao aur bolo");
        status.setTextSize(16);
        status.setTextColor(0xFF5F6368);
        status.setGravity(Gravity.CENTER);
        page.addView(status);

        Button mic = new Button(this);
        mic.setText("Tap to talk");
        mic.setAllCaps(false);
        mic.setOnClickListener(v -> startListening());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 58);
        bp.topMargin = 20;
        page.addView(mic, bp);

        conversation = new TextView(this);
        conversation.setText("Aapki baat yahan dikhegi.\n\nWebhook optional hai — apna Make.com webhook URL neeche paste karein.");
        conversation.setTextColor(0xFF202124);
        conversation.setTextSize(15);
        conversation.setPadding(16, 18, 16, 18);
        conversation.setBackgroundColor(0xFFF1F3F4);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1);
        cp.topMargin = 20;
        page.addView(conversation, cp);

        webhook = new EditText(this);
        webhook.setSingleLine(true);
        webhook.setTextSize(13);
        webhook.setHint("Make.com webhook URL (optional)");
        page.addView(webhook, new LinearLayout.LayoutParams(-1, 54));

        TextView note = new TextView(this);
        note.setText("Note: This starter app listens only after you tap the mic. Always-on “Hey Ajit” needs a separate wake-word engine and background-service setup.");
        note.setTextColor(0xFF777777);
        note.setTextSize(11);
        note.setPadding(2, 10, 2, 0);
        page.addView(note);

        setContentView(page);
    }

    private void setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Is device par speech recognition available nahi hai.");
            return;
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle params) { status.setText("Listening... bolo"); }
            public void onBeginningOfSpeech() { status.setText("Sun raha hoon..."); }
            public void onRmsChanged(float rms) {}
            public void onBufferReceived(byte[] buffer) {}
            public void onEndOfSpeech() { status.setText("Processing..."); }
            public void onError(int error) { status.setText("Voice clear nahi aayi. Dobara try karo."); }
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) handleText(matches.get(0));
            }
            public void onPartialResults(Bundle partialResults) {}
            public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (recognizer == null) setupRecognizer();
        if (recognizer == null) return;
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ajit AI se Hinglish mein baat karein");
        recognizer.startListening(intent);
    }

    private void handleText(String spoken) {
        conversation.setText("You: " + spoken + "\n\nAjit AI: Request received. AI reply ke liye Make.com webhook connect karein.");
        status.setText("Done");
        sendWebhook(spoken);
    }

    private void sendWebhook(String spoken) {
        String endpoint = webhook.getText().toString().trim();
        if (endpoint.isEmpty()) {
            speak("Aapki baat samajh gaya. AI backend connect karne ke liye Make webhook URL add karein.");
            return;
        }
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject body = new JSONObject();
                body.put("text", spoken);
                body.put("assistant", "Ajit AI");
                body.put("language", "Hinglish");
                conn = (HttpURLConnection) new URL(endpoint).openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes("UTF-8"));
                }
                int code = conn.getResponseCode();
                runOnUiThread(() -> status.setText(code >= 200 && code < 300 ? "Webhook connected • request sent" : "Webhook error: " + code));
                speak(code >= 200 && code < 300 ? "Request webhook par send ho gayi." : "Webhook mein problem aa rahi hai.");
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Webhook connect nahi hua. URL check karein."));
                speak("Webhook connect nahi hua. URL check karein.");
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }

    private void speak(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ajit_reply");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
